<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<title> Diss To Drake</title>
		
		<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon" />
		<!-- STEP 1: Build a LINK element to attach the EXTERNAL style sheet located in the 'css' folder - the CSS file is called, 'styles.css' - don't forget to add the rel attribute equal to 'stylesheet' -->
    <link rel="stylesheet" href="css/styles.css" media="screen">

		
	</head>
	<body id="section1">
		<!-- Page-level header -->
		<header>
 		
			<h1>Diss To Drake</h1>

		</header>
		<!-- Page-level main content -->
		<main>
			<!-- News Section -->
			<section>
				<h3>Author: MC Stan</h3>
        <time datetime="2019-03-29">March 29, 2019</time>
				<p>Yo, Drake, I see you claiming the throne
But it's time for you to know you're not alone
I'm MC Stan, stepping up to the plate
To take you down, expose your fake debate</p>
				<!-- First Article -->
				<article>
				
				
					<p>This is the diss track, Drake, prepare for the smack
You've been riding high, but it's time to face the facts
I'm here to call you out, no holding back
MC Stan versus Drake, let's see who'll attack</p>
				</article>
				<!-- Second Article -->
				<article>
					
					
					<p>You used to be authentic, back in the day
But now you're just a puppet in the industry's play
Your sound is generic, your lyrics are weak
I'm here to expose the truth, let the world speak</p>
				</article>
				<!-- Third Article -->
				<article>
					
					
					<p>This is the diss track, Drake, prepare for the smack
You've been riding high, but it's time to face the facts
I'm here to call you out, no holding back
MC Stan versus Drake, let's see who'll attack</p>
				</article>
			</section>
			<!-- Side Notes / Related Information -->
			<aside>
			
					
					   <img src="WhatsApp Image 2023-06-11 at 7.01.09 PM (1).jpeg", width= "180" height="300" />
					
				
			</aside>
		</main>
		
	</body>
</html>
